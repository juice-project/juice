function pines_metadef(){
	juice.debugOutln("hello2");
	juice.addMeta(new JuiceMeta("isbns","#rdetail_isbn")); 
	juice.addMeta(new JuiceMeta("author","#rdetail_author")); 
	juice.addMeta(new JuiceMeta("title","#detail_title")); 
	juice.debugMeta();
}

