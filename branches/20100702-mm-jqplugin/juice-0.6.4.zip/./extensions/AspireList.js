//AspireList.js
//Insert a list of lists this item appears on in the equivilent Aspire Tenant
// @target - target location of page element to be inserted
// @service uri - location of the JSON feed to call
// @opt - object containings value changes {title:"title of the panel", style:'styles to apply', classes:'classes to apply', lcn : 'local control id for testing'}


function AspireListJuice(target, service_uri, opt){

		var settings = jQuery.extend({title: 'Aspire Lists', style:'margin-top:1em;', classes:'tagbox'}, opt);
		var lcn = settings.lcn || juice.getMeta('workid');
		var req = service_uri+'/lcn/'+ lcn +'/lists.json?cb=?';
		
		if(lcn){
			jQuery.getJSON(req, function(data){				
				if(data && data.results.bindings){
					var output='';			
					$.each(data.results.bindings, function(i,item){
						output=output+'<li><a href="'+item.list.value+'">'+item.name.value+'</a></li>';				
					});
					var cont='<div id="aspireList" class="'+settings.classes+'" style="'+settings.style+'"><h2>'+settings.title+'</h2><ul>'+output+'</ul></div>';
					var insert = new JuiceInsert(cont,target,"append");
					insert.show();	
				}
			});
		}
	
}
