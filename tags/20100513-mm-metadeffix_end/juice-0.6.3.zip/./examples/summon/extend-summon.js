//extend-summon.js
//Author Richard Wallis 30/11/09
//Extension file for Talis Prism 2 installations

jQuery(document).ready(function () {
        juice.setDebug(true);
        
        juice.loadJs("http://juice-project.s3.amazonaws.com/extensions/extendedbyJuice.js");
		juice.loadJs("http://juice-project.s3.amazonaws.com/extensions/qrcode_juice.js");
        juice.onAllLoaded(runExtensions);
});

function runExtensions(){
        
        new extendedbyJuice(juice);
}


function buildQRInsert(){
	var qdiv = '<div id="qr_info" style="height: 220px" class="content_container itemservices">' +
	'<div class="content_header">Capture Info</div>'+
	'<div id="QRDiv" style="width: 200px; height: 200px; margin: auto;"></div>' +
	'</div>';
	var qinsert = new JuiceInsert(qdiv,".itemservices","after");
	new qrcodeJuice(juice,qinsert,"QRDiv","title,author,isbns",'\n','s');
}

