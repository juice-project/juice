//extend-talisP2.js
//Author Richard Wallis 13/11/09
//Extension file for Talis Prism 2 installations

jQuery(document).ready(function () {
        juice.setDebug(true);
        
        juice.loadJs("http://juice-project.s3.amazonaws.com/extensions/extendedbyJuice.js");
		juice.loadJs("http://juice-project.s3.amazonaws.com/extensions/GBSEmbed.js");
		juice.loadCss("http://juice-project.s3.amazonaws.com/extensions/TwitterFeed.css");
		juice.loadJs("http://juice-project.s3.amazonaws.com/extensions/TwitterFeed.js");
		juice.loadJs("http://juice-project.s3.amazonaws.com/extensions/qrcode_juice.js");
        juice.onAllLoaded(runExtensions);
});

function runExtensions(){
        
        new extendedbyJuice(juice);

		if(jQuery('div:contains("Popular subjects")').length > 0){
			doJuiceFrontPage();
		}else{
			//Candidate for a MetDef

	        juice.findMeta("isbns","th:contains('ISBN') + td",juice.stringToAlphnumAray);
	        juice.findMeta("title","th:contains('Title:') + td>a");
	        juice.findMeta("author","th:contains('author:') + td>a");

juice.debugOutln("isbns: "+juice.getMeta("isbns"));

			buildQRInsert();
		}

}

function doJuiceFrontPage(){
//	juice.debugOutln("Front");
		
	var tdiv = '<div id="qr_info" style="height: 450px" class="content_container library_info">' +
	'<div class="content_header">Middlemash Tweets</div><br/>'+
	'<div id="tweetdiv" style="width: 270px; height: auto; margin: auto;"></div>' +
	'</div>';
	var jinsert = new JuiceInsert(tdiv,".library_info","after");

	var twitops = {
		height : "430px",
		width : "260px",
		showAvatar : true,
		showId : true,
		showLink : true,
		count: 5
	};
	new TwitterFeedJuice(juice,jinsert,"tweetdiv","#middlemash",twitops);


}


function buildQRInsert(){
	var qdiv = '<div id="qr_info" style="height: 220px" class="content_container itemservices">' +
	'<div class="content_header">Capture Info</div>'+
	'<div id="QRDiv" style="width: 200px; height: 200px; margin: auto;"></div>' +
	'</div>';
	var qinsert = new JuiceInsert(qdiv,".itemservices","after");
	new qrcodeJuice(juice,qinsert,"QRDiv","title,author,isbns",'\n','s');
}

