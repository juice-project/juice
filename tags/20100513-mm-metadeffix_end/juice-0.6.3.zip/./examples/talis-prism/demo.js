juice.loadJs("http://juice-project.s3.amazonaws.com/extensions/JuiceSimpleInsert.js");


juice.onJsLoaded(runExtensions);

function runExtensions(){
	demo_loadStatus();
	XbuildExtendedBy();
}

function XbuildExtendedBy(){
	var div = '<div id="extendedBy" style="display: block; width: 100%; text-align: center;">' +
	'<span id="demoClick">Extended by </span><a href="javascript:void(0)">The Juice Project</a></div>';
	var insert = new JuiceInsert(div,"body","append");
	var procExtendedBy = new simpleInsertJuice(juice,insert,function(){$jq("#extendedBy").click(demo_showStatus);});
}

var defdemoExts = {
	Worldcat: false,
	AmazonUK: false,
	AudibleUK: false,
	GoogleBS: false,
	GoogleBSEmbeded: false,
	BhamMap: false,
	UCDMap: false,
}

var demoExts;

function demo_loadStatus(){
	demoExts = defdemoExts;
	var saved = juice.getCookie("demoOpts");
	if(saved){
		var opts = saved.split('&');
		for(var i in opts){
			opt = opts[i].split('=');
			demoExts[opt[0]] = opt[1];
		}
	}
	demo_saveStatus();
}

function demo_showStatus(){
	if($jq("#demoStaus").length == 0){
		var tbl = $jq('<table class="demoStatusTable"/>');
		for(var i in demoExts){
			var row = '<tr><td>'+ i + '</td><td>';
			row += '<input type="checkbox" value="' + i + '" ' ;
			if(demoExts[i] == "true"){
				row += ' checked="checked" ';
			}
			row += ' />'
			row += '</td></tr>';
			tbl.append(row);
		}
		var div = $jq('<div id="demoStaus" style="display: block; width: 300px; background-color: white; border: 1px; border-color: black;"/>');
		div.append('<div style="display: block; clear: both; font-weight: bold; text-align: center">Extensions</div>');
		div.append(tbl);
		var insert = new JuiceInsert(div,"body","after");
		var procExtendedBy = new simpleInsertJuice(juice,insert,function(){$jq(":checkbox").click(setChecked)});
	}	
}

function setChecked(){
	$jq("#demoStaus :checkbox").each(function(i){
		juice.debugOutln("hello "+i);
//		juice.debugOutln(this.attr("checked") + " - " + this.attr("name"));
	});
}

function demo_saveStatus(){
	var state = $jq.param(demoExts);
	juice.setCookie("demoOpts",state,0,0,1);
}