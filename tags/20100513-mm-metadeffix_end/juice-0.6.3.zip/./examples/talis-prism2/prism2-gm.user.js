// ==UserScript==
// @name          Prism 2 GM Script
// @namespace     http://www.talis.com
// @description   Juice embed in Talis Prism 2
// @include       http://193.62.51.218/TalisPrism/*
// ==/UserScript==


function myloadjs(file){
	var juhead = document.getElementsByTagName('head')[0]; 
	var juins = document.createElement('script'); 
	juins.type = 'text/javascript'; 
	juins.src = file; 
	juhead.appendChild(juins); 
}

myloadjs("http://juice-project.s3.amazonaws.com/jquery-1.3.2.min.js");
myloadjs("http://juice-project.s3.amazonaws.com/juice.js");
myloadjs("http://juice-project.s3.amazonaws.com/examples/talis-prism2/extend-talisP2-fromaws.js")
