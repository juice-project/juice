

function BookListFromFeed(ju,insert,targetDiv,opts){
	this.id = "BookListFromFeed";
	this.targetDiv = targetDiv;
	var defOpts = {
		height : "200px",
		width : "300px",
		feedUrl: null,
		items : []
	};
	this.opts = juice.updateArray(defOpts,opts);
	var initFunc = this.start;
	if(arguments.length){
		if(this.opts.feedUrl){
			juice.loadGoogleApi("feeds", "1");
		}
		BookListFromFeed.superclass.init.call(this,this.id,initFunc,null,insert,ju);
		BookListFromFeed.superclass.startup.call(this);
	}

}

BookListFromFeed.prototype = new JuiceProcess();
BookListFromFeed.prototype.constructor = BookListFromFeed;
BookListFromFeed.superclass = JuiceProcess.prototype;

BookListFromFeed.prototype.start = function(){
	var This = this;
	juice.ready(function(){This.initList();});
}

BookListFromFeed.prototype.initList = function(){
	if(this.opts.feedUrl){
		//get data from feed then call startList()
		this.getItemsFromFeed(this.opts.feedUrl);
	}else{
		this.startList();
	}
}

BookListFromFeed.prototype.startList = function(){
	var This = this;
	this.setupDivs();
//	this.setupCarousel();
//	setInterval(function(){This.startCarousel();},40);

}

BookListFromFeed.prototype.setupDivs = function(){

	var cont = $jq('<div id="' + this.id + '" ' + 'class="juice_book_list" ' +
		'style="display: block; background-color: transparent; ' +
		'padding: 0; border: 0; margin-left: auto; margin-right: auto; ' +
		'width: ' +  this.opts.width + '; ' +
		'height: ' +  this.opts.height + '"/>');
		
	
	var items = this.opts.items;
	juice.debugOutln("setupDivs "+items.length);
	for(var i = 0; i < items.length  ; i++){
//		for(var i = 0; i < items.length  && i < this.opts.max ; i++){
		juice.debugOutln("setupDivs + "+i);
		cont.append(this.itemHTML(items[i]));
	}
	this.showInsert();
	
	var insert = new JuiceInsert(cont,"#"+this.targetDiv,"append");
	insert.show();
	
}

BookListFromFeed.prototype.itemHTML = function(item) {
	juice.debugOutln("itemHTML");
        var html = '<div class=\"item\">'+
        '<div class=\"image\">' +
        '<a title=\"'+item.author+'\" href=\"'+item.link+'\">' +
        '<img src=\"'+item.media.m+'\" alt=\"'+item.author+'\"/>' +
        '</a>' +
        '</div>' +
        '<div class=\"summary\">' +
        '<h2 class=\"title\">' +
        '<a title=\"'+item.author+'\" href=\"'+item.link+'\">' +
        ''+item.title+'' +
        '</a>' +
        '</h2>' +
        '</div>' +
        '<div class=\"summary\">' +
        '<div class=\"description\">' +
        '<div class=\"author\"><span class=\"author\">by</span> ' +
        '<span class=\"author\">' +
        ''+item.author+'' +
        '</span>' +
        '</div>' +
        '<div class=\"summarydetail\">' +
        '<span class=\"summarydetail\">' +
        ''+item.descriptions+'' +
        '</span>' +
        '</div>' +
        '<blockquote>' +
        '<span class=\"author\"/>' +
        '</blockquote>' +
        '</div>' +
        '</div>' +
        '</div>';
        return html;
}

BookListFromFeed.prototype.getItemsFromFeed = function(url){
	var This = this;
	var feed = new google.feeds.Feed(url);
	feed.setResultFormat(google.feeds.Feed.MIXED_FORMAT);
	feed.setNumEntries(10);
	feed.load(function(result) {
		var items = [];
	  if (!result.error) {
	    for (var i = 0; i < result.feed.entries.length; i++) {
	      var entry = result.feed.entries[i];
		juice.debugOutln("getItemsFromFeed "+ i + " " +entry.title);

			var item = {
				media : { m : This.getImageLink(google.feeds.getElementsByTagNameNS(entry.xmlNode, "http://www.w3.org/2005/Atom", "link")) },
				title : entry.title,
				link : entry.link,
				author : ,
				descriptions : entry.id
				
			};
			items.push(item);
		}
	  }else{
		juice.debugOutln("ERROR: "+result.error);
	  }
	This.opts.items = items;
	This.startList();
	});	
}

BookListFromFeed.prototype.getImageLink = function(elems){
	for(var i = 0 ; i < elems.length; i++){
		ele = elems[i];
		if(ele.getAttribute('rel') == 'image'){
			return ele.getAttribute('href');
		}
	}
	return "";
	
}